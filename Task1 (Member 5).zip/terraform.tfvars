# The ID of your existing VPC
vpc_id = "vpc-0a1b2c3d4e5f6g7h8" 

# The IDs of the subnets where the RDS will live (DB Subnets)
private_subnet_ids = [
  "subnet-0123456789abcdef0", 
  "subnet-0abcdef0123456789"
]

# The IP Ranges of the subnets allowed to talk to the DB (App Subnets)
private_subnet_cidrs = [
  "10.0.10.0/24", 
  "10.0.11.0/24"
]
